export class SignUpInfo {
  name: string;
  username: string;
  email: string;
  password: string;
  user: string;
  constructor() {}
}
