export class AuthLoginInfo {
    username: string;
    password: string;
    constructor() {}
}
