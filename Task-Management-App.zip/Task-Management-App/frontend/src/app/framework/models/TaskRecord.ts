export class TaskRecord {
  id: number;
  trainee: number;
  task: number;
  status: string;
  score: number;
  max: number;
  remarks: string;
  work: string;
}
