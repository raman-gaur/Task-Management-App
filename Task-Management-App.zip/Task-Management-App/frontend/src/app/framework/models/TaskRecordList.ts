import { TaskRecord } from './TaskRecord';

export class TaskRecordList {
  public taskRecordList: TaskRecord[];
}
