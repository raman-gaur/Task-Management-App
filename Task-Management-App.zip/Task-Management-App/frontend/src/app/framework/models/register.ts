export class Register {
  username: string;
  email: string;
  password: string;
  user: string;
  constructor() {}
}
