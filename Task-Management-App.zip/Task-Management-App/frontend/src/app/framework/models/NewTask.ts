import { Task } from './Task';

export class NewTask {
  public task: Task;
  public user: number[] = [];

  constructor() {
    }
}
