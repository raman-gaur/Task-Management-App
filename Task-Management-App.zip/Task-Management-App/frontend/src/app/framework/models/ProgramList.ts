import { Program } from './Program';

export class ProgramList {

  programList: Program[];

  constructor() {}
}
