import { Task } from 'src/app/framework/models/Task';

export class TaskList {
  taskList: Task[];
  constructor() {}
}
